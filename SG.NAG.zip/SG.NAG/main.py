#make NeuralNetwork
#load mnist
#forward processing
#find loss function
import numpy as np
import pandas as pd
from neural import *
import matplotlib.pyplot as plt


loss_list = []

NN = NeuralNetwork(1, 7, 1)
data = func_sin()
x, t = data.data()
x = x.reshape(-1, 1)
t = t.reshape(-1, 1)
w = NN.first_params()

trials = 100000



for i in range(trials):

    params = NN.split_params(w)
    #print(params)
    loss, grads, params = NN.NN(x, t, params)
    loss_list.append(loss)
    w = NN.conect_params()
    params = NN.SG(w, grads)

    if i % 1000 == 0:
        print(loss)

df = pd.DataFrame(loss_list)
df.to_csv("out.csv")


#print(loss)
markers = {'loss'}
x = np.arange(len(loss_list))
plt.loglog(x, loss_list, label='loss')

plt.xlabel("trial_number")
plt.ylabel("loss")
plt.plot(0, np.max(loss_list))
plt.legend(loc='upper right')
plt.show()
